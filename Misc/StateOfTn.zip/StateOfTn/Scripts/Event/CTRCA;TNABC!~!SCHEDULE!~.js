
if (AInfo['Program Certificate ID'] != null) {
	copyLicensedProf(parentCapId, capId);
}
