
// DISABLED: DUA:TNABC/Retail/License/Retail Package Store:05
// var docList = getDocumentList();
// var catFound = false;
// for (d in docList) if (docList[d].getDocCategory().equals('Consumer Education Seminar')) catFound = true;
// aa.print('Cat Found: ' + catFound);
// DISABLED: DUA:TNABC/Retail/License/Retail Package Store:10
// if (catFound) {
// 	addAdHocTask('ABC TASKS','Consumer Education Documentation Uploaded','');
// 	}

