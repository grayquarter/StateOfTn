
// DISABLED: ASA:TNABC/Liquor by the Drink/Application/Special Occasion:00
// if (publicUser) {
// 	addFee('SPO-LIC','TABC-SPO-A','FINAL',1,'Y');
// 	}

addSpcOccEventAsParent(AInfo['Secretary of State Control Number']);
