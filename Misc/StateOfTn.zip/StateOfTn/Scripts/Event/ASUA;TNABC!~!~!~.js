
if (capStatus == 'Void') {
	taskCloseAllExcept('Void');
}

if (capStatus == 'Withdrawn') {
	taskCloseAllExcept('Withdrawn');
}
