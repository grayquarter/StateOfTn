
if (!publicUser) {
	licCapId = capId;
	generateChangeAltID(capId);
	newLicId = capId;
	updateChangeAltID(newLicId);
}
