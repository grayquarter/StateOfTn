
// DISABLED: ASIUA:TNABC/*/Citation/*:02
// if (AInfo['Assess Fines?'] == 'Yes') {
// 	br_nch('TABC_ASSESS_FINES');
// 	}
