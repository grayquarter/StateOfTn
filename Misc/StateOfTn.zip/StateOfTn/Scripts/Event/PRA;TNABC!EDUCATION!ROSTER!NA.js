
if (balanceDue == 0) {
	updateAppStatus('Closed', 'Closed via Payment - EMSE');
}
