
if (wfTask == 'Planning' && wfStatus == 'Plan Approval') {
	//replaced branch(TABC_Create_Target_Records_0)
	createTargetRecords0();
}

//replaced branch(WTUA:TNABC/*/Application/* Update Status)
applicationUpdateStatus();
