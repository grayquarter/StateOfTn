
if (isTaskActive('Execution')) {
	//replaced branch(TABC_Create_Target_Records_0)
	createTargetRecords0();
}
