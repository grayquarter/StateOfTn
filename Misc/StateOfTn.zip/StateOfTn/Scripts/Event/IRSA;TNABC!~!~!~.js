
// DISABLED: IRSA:TNABC/*/*/*:01
// if (matches(inspResult,'Correct Onsite-Citation Issued','Correct Needed-Citation Issued')) {
// 	var citationChild = createChild('TNABC','Enforcement','Citation','NA','');
// 	copyLicensedProf(capId, citationChild);
// 	if (appTypeArray[2].equals('License')) editAppSpecific('License Number',capIDString,citationChild);
// DISABLED: IRSA:TNABC/*/*/*:10
// 	var county = getCountyValue(capId);
// 	if (county != null) editAppSpecific('County',county,citationChild);
// 	updateEnfOfficer(currentUserID);
// DISABLED: IRSA:TNABC/*/*/*:15
// 	var insReqHear = false;
// 	var inspGuideItems = new Array();
// 	inspGuideItems = getGuideSheetObjects(inspId);
// 	for (iG in inspGuideItems) aa.print(iG + ' = ' + inspGuideItems[iG].'Hearing Requested');
// 	}

// DISABLED: IRSA:TNABC/*/*/*:20
// if (matches(inspResult,'Correct Onsite-Citation Issued','Correct Needed-Citation Issued') && insReqHear) {
// 	holdId = capId;
// 	capId = citationChild;
// 	matches(inspResult,'Correct Onsite-Citation Issued','Correct Needed-Citation Issued');
// 	capId = holdId;
// 	}

// DISABLED: IRSA:TNABC/*/*/*:55
// if (matches(inspResult,'Fail','Correct Needed-Citation Issued')) {
// 	createPendingInspection(inspGroup,'Follow-up Inspection');
// 	}

// DISABLED: IRSA:TNABC/*/*/*:999b
// if (issueCitation) {
// 	var citationChild = createChild('TNABC','Enforcement','Citation','NA','');
// 	editAppSpecific('License Number',capIDString,citationChild);
// 	}

