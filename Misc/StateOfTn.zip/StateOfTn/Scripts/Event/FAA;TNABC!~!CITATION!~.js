
// DISABLED: FAA:TNABC/*/Citation/*:10
// licCitConds = new Array();
// licCitConds = getLicenseConditions('Citation', 'Applied','Outstanding citation fines exist','Notice');
// if (licCitConds.length <= 0) addLicenseStdConditionWGroup('','Citation','Outstanding citation fines exist');
// DISABLED: FAA:TNABC/*/Citation/*:15
// if (feeExists('CIT002')) {
// 	logDebug('editing Ref LP Sale to Minor');
// 	var saleToMinorCount = editRefLPASI('Sale To Minor',1);
// 	}

// DISABLED: FAA:TNABC/*/Citation/*:20
// if (feeExists('CIT002') && saleToMinorCount >1) {
// 	if (!isTaskActive('Sale To Minor','ABC TASKS')) addAdHocTask('ABC TASKS','Multiple Sale To Minor','Multiple Sale to Minor Citations have been issued');
// DISABLED: FAA:TNABC/*/Citation/*:25
// 	licStMConds = new Array();
// 	licStMConds = getLicenseConditions('Citation', 'Applied','Sale To Minor','Notice');
// 	if (licStMConds.length <= 0) addLicenseStdConditionWGroup('','Citation','Sale To Minor');
// 	}
