
// DISABLED: WTUA:TNABC/Hearing/NA/*:01
// if (wfTask.equals('Notice of Hearing') && wfStatus.equals('Hearing Set')) {
// 	removeLPConditions('Citation','Applied','Outstanding citation fines exist','Notice');
// 	editTaskDueDate('Hearing',AInfo['Hearing Date']);
// 	}

// DISABLED: WTUA:TNABC/Hearing/NA/*:999
// if (typeof(HEARINGINFO) == 'object') {
// 	vDate=HEARINGINFO[0]['Scheduled Date'];
// 	vLoc=HEARINGINFO[0]['Location'];
// 	vTime=HEARINGINFO[0]['Time'];
// DISABLED: WTUA:TNABC/Hearing/NA/*:999a
// 	Hcomm ='Hearing Schedule details : Date : '+vDate + '     Location : '+vLoc+'       Time : '+vTime;
// 	editTaskComment ('Commission Agenda', Hcomm);
// 	}
