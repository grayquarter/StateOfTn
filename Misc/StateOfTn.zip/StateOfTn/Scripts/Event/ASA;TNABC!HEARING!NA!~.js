
if (AInfo['License Number']) {
	addParent(AInfo['License Number']);
}
