
if (appMatch('TNABC/Permits/Application/Armed Forces Import')) {
	licEditExpInfo(null, AInfo['Exact date of shipment']);
}
