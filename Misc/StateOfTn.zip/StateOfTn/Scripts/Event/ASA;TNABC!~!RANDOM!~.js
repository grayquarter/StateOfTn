
// DISABLED: ASA:TNABC/*/Random/*:01
//licCapId = capId;
//generateAltID(capId);
//newLicId = capId;
//updateAltID(newLicId);
