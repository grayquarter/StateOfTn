# StateOfTn

Gray Quarter, Inc. has upgraded the agency scripts extracted from the TABC Production environment
from the version 2.x format to the newest scripting version 3.0 format. The original scripts that were
stored in standard choices have been migrated into JavaScript files, using the Accela best practice
directory structure. These standard choices have been converted to a structure that mirrors the
record type structure for the agency. 
