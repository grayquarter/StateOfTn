function getCapByCustomID(custID)
{
	return aa.cap.getCapID(custID).getOutput();
}

